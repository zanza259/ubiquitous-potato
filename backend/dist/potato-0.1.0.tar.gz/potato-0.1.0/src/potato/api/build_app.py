
def build_app() -> None:
    pass
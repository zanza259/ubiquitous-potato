
import argparse
import asyncio
import logging
import uvicorn
from pathlib import Path
from src.logs import QueueHandler, LOG_QUEUE
from src.api.build_app import build_app

# setup root logger
root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)

queue_handler = QueueHandler(log_queue=LOG_QUEUE)
queue_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
)

root_logger.addHandler(queue_handler)

# setup module logger
logger = logging.getLogger(__name__)

class Runner:

    def __init__(self, db_path: Path, port: int) -> None:
        self._db_path = db_path
        self._port = port

    async def run(self) -> None:
        logger.info(f"Starting backend with database at {self._db_path}")

        fast_api_app = build_app()

        config = uvicorn.Config(
            app=fast_api_app,
            port=self._port,
            log_level="info", # make sure uvicorn doesn't override the logging level if we set it elsewhere
            log_config=None, # make sure that uvicorn doesn't override the global logger configuration
            access_log=False, # disable access log to prevent prometheus metric harvesting spamming logs
            lifespan="on", # lifespan to ensure startup/shutdown events are handled
            host="0.0.0.0",
        )

        server = uvicorn.Server(config=config)

        try:           
            await server.serve()
        finally:
            logger.info("Shutting down backend")
            await server.shutdown()
            print("Backend shutdown complete")

def build_arg_parser():

    parser = argparse.ArgumentParser(description="Recipe Management Backend")

    parser.add_argument(
        "--db",
        type=Path,
        default=Path.home() / "recipes.db",
        help="Path to the designated sqlite database file.",
    )

    parser.add_argument(
        "--port",
        type=int,
        default=8090,
        help="Port to run the backend server on.",
    )

    return parser

def main():
    args = build_arg_parser().parse_args()

    runner = Runner(db_path=args.db,)
    asyncio.run(runner.run())

if __name__ == "__main__":
    main()